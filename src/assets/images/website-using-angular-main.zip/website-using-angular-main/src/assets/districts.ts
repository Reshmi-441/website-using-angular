export const districtDetails = [
    {
        name:'ALAPPUZHA',
        image:'alappuzha.jpg'
        },
    {
        name: 'ERNAKULAM',
        image:'ERNAKU.cms'

    },
    {
        name:'KOZHIKODE',
        image:'KOZHI.png'
    },
    {
        name:'PALAKKAD',
        image:'PALA.jpeg'
    },
    {
        name:'kOLLAM',
        image:'KOLLAM.jpg'
    },
    {
        name:'KANNUR',
        image:'KANNUR.jpg'
    },
    {
        name:'KASARGODE',
        image:'KASARGO.jpeg'
    },
    {
        name:'IDUKKI',
        image:'IDUKKI.jpg'
    },
    {
        name:'KOTTAYAM',
        image:'KOTTAYAM.jpg',
    
    },
    {
        name:'THRISSUR',
        image:'THRISSUR.jpg',
    
    },
    {
        name:'PATHANAMTHITTA',
        image:'PATHANAM.jpg',
        
    },
    {
        name:'MALAPPURAM',
        image:'MALA.png',
        
    },
    {
        name:'WAYANAD',
        image:'WAYANAD.jpg'
    },
    {
        name:'THIRUVANATHAPURAM',
        image:'TRIVANDRUM.jpg'
    },



]